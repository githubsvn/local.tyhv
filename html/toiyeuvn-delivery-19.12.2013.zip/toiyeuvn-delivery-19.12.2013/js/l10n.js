var L10n = {
  required: {
    username: 'please enter your name',
    password: 'please enter your password',
    email: 'please enter email address'
  },
  valid: {
    email: 'please enter valid email address'
  },
  confirm: {
    user: 'are you sure you want to delete?'
  },
  alert: {
    user: 'your account has been created successfully'
  } 
};